/**
 * 	Author		: Juan P. Munoz
 *	Date		: Feb 22, 2022
 *	File		: BasketballPlayer.java
 *	Description	: The BasketballPlayer is a sub-class that extends the super
 *				  class Player.  The BasketballPlayer class receives 
 *				  the number of shots made by the player and the number of shots
 *				  Attempted by the player. With these variables calculates 
 *				  the statistics of a player. Also determine the status of 
 *				  the player to be true or false. 
 */

public class BasketballPlayer extends Player {
	
	private int numberOfShotsMade;	// An int variable to hold the number of shots 
									// made by the player.
	
	private int numOfShotsAttem;	// An int variable to hold the number of shots 
									// attempted by the player.
	
	public static final double CHECKPOINT = 0.32;	// Creates the check point to
													// determine the player status.
	
	// Creates a default constructor.
	public BasketballPlayer () {
		
	}
	
	// Creates a constructor with eight parameters, two from the sub-class
	// and six from the super class.
	public BasketballPlayer ( int id, String playerName, String teamName, 
			String position, Double salary, double commissionRate,
			int numberOfShotsMade, int numOfShotsAttem) {
		
		setId(id);
		setPlayerName(playerName);
		setTeamName(teamName);
		setPosition(position);
		setSalary(salary);
		setCommissionRate(commissionRate);
		this.numberOfShotsMade= numberOfShotsMade;
		this.numOfShotsAttem = numOfShotsAttem;
		
	}
	
	// Getters Methods.
	/**
	 * @return the numberOfShotsMade
	 */
	public int getNumberOfShotsMade() {
		return numberOfShotsMade;
	}

	/**
	 * @return the numOfShotsAttem
	 */
	public int getNumOfShotsAttem() {
		return numOfShotsAttem;
	}
	
	// Setters Methods.
	/**
	 * @param numberOfShotsMade the numberOfShotsMade to set
	 */
	public void setNumberOfShotsMade(int numberOfShotsMade) {
		this.numberOfShotsMade = numberOfShotsMade;
	}

	/**
	 * @param numOfShotsAttem the numOfShotsAttem to set
	 */
	public void setNumOfShotsAttem(int numOfShotsAttem) {
		this.numOfShotsAttem = numOfShotsAttem;
	}
	
	// A double data type method to calculate the player's shot percentage.
	public double calculateStatistics() {
		
		double percentage = ((double) numberOfShotsMade / numOfShotsAttem);
		return percentage;
			
	}
		
	// A boolean data type method to determine the player's status.
	// If the player's average is .32 or greater returns true, 
	// otherwise returns false.
	public boolean determineStatus() {
		
			
		if (calculateStatistics() >= CHECKPOINT) {
			return true;
		}
		else {
			return false;
		}
	}
	
}

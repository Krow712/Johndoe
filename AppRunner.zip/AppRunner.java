/**
 * 	Author		: Juan P. Munoz
 *	Date		: Feb 22, 2022
 *	File		: AppRunner.java
 *	Description	: This is a file runner for the Player class and it's sub-classes.
 *				  In the main method four instances are created, two for the 
 *				  BaseballPlayer class and two for the BasketballPlayer class. 
 *				  Invoking the profile created for a specific player in the super class.
 *				  Also invokes the statistics and status methods from both sub-classes.
 *				  It also displays the player profile to the screen for the user.   
 */

public class AppRunner {

	public static void main(String[] args) {
		 
		
		// Creates two instances of the BaseballPlayer class.
		// First BaseballPlayer instance.
		BaseballPlayer basePlayer1 = new BaseballPlayer(
				20, "Mike Jang", "SF Giants", "Left Fielder", 200000.00, 0.02, 10, 70);
		
		// Second BaseballPlayer instance.
		BaseballPlayer basePlayer2 = new BaseballPlayer( 
				25, "Jered Luge", "Houston Astros", "Pitcher", 300000.00, 0.04, 30, 50);
		
		// Creates two instances of the BasketballPlayer class.
		// First BasketballPlayer instance.
		BasketballPlayer basketPlayer1 = new BasketballPlayer( 
				12, "Demar Rozier", "Milwaukee Bucks", "Center", 400000.00, 0.03, 10, 50);
		
		// Second BasketballPlayer instance.
		BasketballPlayer basketPlayer2 = new BasketballPlayer( 
				19, "KD Garnett", "Brooklyn Nets", "Point Guard", 250000.00, 0.02, 45, 125);
		
		
		// Display a welcome message for the user.
		System.out.println("***************************************************");
		System.out.println("*********** Welcome To The Player's APP ***********");
		System.out.println("***************************************************");
		System.out.println();
		
		
		// Display a header for the first baseball player's profile.
		System.out.println("****************************");
		System.out.println("***** Player's Profile *****");
		System.out.println("****************************");
		System.out.println();
		
		
		// Display the player id number.
		System.out.printf("\nPlayer's ID                   : %-3d", 
		basePlayer1.getId());
		
		// Display the player's name.
		System.out.printf("\nPlayer's Name                 : %-15s", 
		basePlayer1.getPlayerName());
		
		// Display the team name.
		System.out.printf("\nPlayer's Team                 : %-15s",  
		basePlayer1.getTeamName());
		
		// Display the player's position.
		System.out.printf("\nPlayer's Position             : %-15s", 
		basePlayer1.getPosition());
		
		// Display the players's salary.
		System.out.printf("\nPlayer's Salary               : $%-8.2f", 
		basePlayer1.getSalary());
		
		// Display the player's commission rate.
		System.out.printf("\nPlayer's Commission Rate      : %-3.2f%%", 
		basePlayer1.getCommissionRate());
		
		// Display the player's commission amount. 
		System.out.printf("\nPlayer's Total Commission     : $%-8.2f", 
		basePlayer1.CalculateCommission());
	 	
		// Display the number of hits made by the player.
		System.out.printf("\nNumber Of Hits                : %-4d", 
		basePlayer1.getNumberOfHits());
		
		// Display the number of times that the player was at the bat.
		System.out.printf("\nNumber Of Times At The Bat    : %-4d", 
		basePlayer1.getNumOfTimesAtBat());
		
		// Display the player's statistics.
		System.out.printf("\nPlayer's Statistics           : %-3.2f", 
		basePlayer1.calculateStatistics());
		
		// Display True if the player is keeping a good status or
		// Display False if the player is not keeping a good status.
		System.out.printf("\nIs The Player Keeping Status? : %-5s", 
		basePlayer1.determineStatus());
		System.out.println();
		
		
		// Display a header for the second baseball player profile.
		System.out.println();
		System.out.println();
		System.out.println("****************************");
		System.out.println("***** Player's Profile *****");
		System.out.println("****************************");
		System.out.println();
		
		
		// Displays the player id number.
		System.out.printf("\nPlayer's ID                   : %-3d", 
		basePlayer2.getId());
		
		// Display the player's name.
		System.out.printf("\nPlayer's Name                 : %-15s", 
		basePlayer2.getPlayerName());
		
		// Display the team name.
		System.out.printf("\nPlayer's Team                 : %-15s",  
		basePlayer2.getTeamName());
		
		// Display the player's position.
		System.out.printf("\nPlayer's Position             : %-15s", 
		basePlayer2.getPosition());
		
		// Display the players's salary.
		System.out.printf("\nPlayer's Salary               : $%-8.2f", 
		basePlayer2.getSalary());
		
		// Display the player's commission rate.
		System.out.printf("\nPlayer's Commission Rate      : %-3.2f%%", 
		basePlayer2.getCommissionRate());
		
		// Display the player's commission amount.
		System.out.printf("\nPlayer's Total Commission     : $%-8.2f", 
		basePlayer2.CalculateCommission());
		
		// Display the number of hits made by the player.
		System.out.printf("\nNumber Of Hits                : %-4d", 
		basePlayer2.getNumberOfHits());
		
		// Display the number of times that the player was at the bat.
		System.out.printf("\nNumber Of Times At The Bat    : %-4d", 
		basePlayer2.getNumOfTimesAtBat());
		
		// Display the player's statistics.
		System.out.printf("\nPlayer's Statistics           : %-3.2f", 
		basePlayer2.calculateStatistics());
				
		// Display True if the player is keeping a good status or
		// Display False if the player is not keeping a good status.
		System.out.printf("\nIs The Player Keeping Status? : %-5s", 
		basePlayer2.determineStatus());
		System.out.println();
		
		
		// Display a header for the first basketball player's profile.
		System.out.println();
		System.out.println();
		System.out.println("****************************");
		System.out.println("***** Player's Profile *****");
		System.out.println("****************************");
		System.out.println();
		
		
		// Displays the player id number.
		System.out.printf("\nPlayer's ID                   : %-3d", 
		basketPlayer1.getId());
		
		// Display the player's name.
		System.out.printf("\nPlayer's Name                 : %-15s", 
		basketPlayer1.getPlayerName());
		
		// Display the team name.
		System.out.printf("\nPlayer's Team                 : %-15s",  
		basketPlayer1.getTeamName());
		
		// Display the player's position.
		System.out.printf("\nPlayer's Position             : %-15s", 
		basketPlayer1.getPosition());
		
		// Display the players's salary.
		System.out.printf("\nPlayer's Salary               : $%-8.2f", 
		basketPlayer1.getSalary());
		
		// Display the player's commission rate.
		System.out.printf("\nPlayer's Commission Rate      : %-3.2f%%", 
		basketPlayer1.getCommissionRate());
		
		// Display the player's commission amount.
		System.out.printf("\nPlayer's Total Commission     : $%-8.2f", 
		basketPlayer1.CalculateCommission());
		
		// Display the number of shots made by the player.
		System.out.printf("\nNumber Of Shots Made          : %-4d", 
		basketPlayer1.getNumberOfShotsMade());
		
		// Display the number of shots attempted by the player.
		System.out.printf("\nNumber Of Shots Attempted     : %-4d", 
		basketPlayer1.getNumOfShotsAttem());
		
		// Display the player's statistics.
		System.out.printf("\nPlayer's Statistics           : %-3.2f", 
		basketPlayer1.calculateStatistics());
		
		// Display True if the player is keeping a good status or
		// Display False if the player is not keeping a good status.
		System.out.printf("\nIs The Player Keeping Status? : %-5s", 
		basketPlayer1.determineStatus());
		System.out.println();
		
		
		// Display a header for the second basketball player profile.
		System.out.println();
		System.out.println();
		System.out.println("****************************");
		System.out.println("***** Player's Profile *****");
		System.out.println("****************************");
		System.out.println();
	
		
		// Displays the player id number.
		System.out.printf("\nPlayer's ID                   : %-3d", 
		basketPlayer2.getId());
		
		// Display the player's name.
		System.out.printf("\nPlayer's Name                 : %-15s", 
		basketPlayer2.getPlayerName());
		
		// Display the team name.
		System.out.printf("\nPlayer's Team                 : %-15s",  
		basketPlayer2.getTeamName());
		
		// Display the player's position.
		System.out.printf("\nPlayer's Position             : %-15s", 
		basketPlayer2.getPosition());
		
		// Display the players's salary.
		System.out.printf("\nPlayer's Salary               : $%-8.2f", 
		basketPlayer2.getSalary());
		
		// Display the player's commission rate.
		System.out.printf("\nPlayer's Commission Rate      : %-3.2f%%", 
		basketPlayer2.getCommissionRate());
		
		// Display the player's commission amount.
		System.out.printf("\nPlayer's Total Commission     : $%-8.2f", 
		basketPlayer2.CalculateCommission());
		
		// Display the number of shots made by the player.
		System.out.printf("\nNumber Of Shots Made          : %-4d", 
		basketPlayer2.getNumberOfShotsMade());
		
		// Display the number of shots attempted by the player.
		System.out.printf("\nNumber Of Shots Attempted     : %-4d", 
		basketPlayer2.getNumOfShotsAttem());
		
		// Display the player's statistics.
		System.out.printf("\nPlayer's Statistics           : %-3.2f", 
		basketPlayer2.calculateStatistics());
		
		// Display True if the player is keeping a good status or
		// Display False if the player is not keeping a good status.
		System.out.printf("\nIs The Player Keeping Status? : %-5s", 
		basketPlayer2.determineStatus());
		System.out.println();
		
		
		// Display a thank you message for the user.
		System.out.println();
		System.out.println();
		System.out.println("***************************************************");
		System.out.println("***** Thank You For Your Visit, Come Again. *******");
		System.out.println("***************************************************");
		
	}

}

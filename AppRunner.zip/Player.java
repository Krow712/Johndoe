/**
 * 	Author		: Juan P Munoz.
 *	Date		: Feb 21, 2022
 *	File		: Player.java
 *	Description	: This is a super class that works as a blueprint 
 *				  for a player personal information registry.
 */

public class Player {
	private int id;				// Int variable to hold the player's id number. 
	private String playerName;	// String variable to hold the player's name.
	private String teamName;	// String variable to hold the player's team name.
	private String position;	// String variable to hold the player's position.
	private double salary;		// double variable to hold the player's salary.
	private double commissionRate; // double variable to hold the player's commission rate. 
	
	// Creates a default constructor.
	public Player() {
		
	}
	// Creates a constructor with six parameters. 
	/**
	 * @param id
	 * @param playerName
	 * @param teamName
	 * @param position
	 * @param salary
	 * @param commissionRate
	 */
	public Player(int id, String playerName, 
			String teamName, String position, 
			double salary, double commissionRate) {
		this.id = id;
		this.playerName = playerName;
		this.teamName = teamName;
		this.position = position;
		this.salary = salary;
		this.commissionRate = commissionRate;
	}
	
	// Getters Methods.
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return the playerName
	 */
	public String getPlayerName() {
		return playerName;
	}

	/**
	 * @return the teamName
	 */
	public String getTeamName() {
		return teamName;
	}

	/**
	 * @return the position
	 */
	public String getPosition() {
		return position;
	}

	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}

	/**
	 * @return the commissionRate
	 */
	public double getCommissionRate() {
		return commissionRate;
	}
	
	
	// Setters Methods.
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param playerName the playerName to set
	 */
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	/**
	 * @param teamName the teamName to set
	 */
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	/**
	 * @param position the position to set
	 */
	public void setPosition(String position) {
		this.position = position;
	}

	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}

	/**
	 * @param comissionRate the comissionRate to set
	 */
	public void setCommissionRate(double commissionRate) {
		this.commissionRate = commissionRate;
	}
	
	// Creates a double data type method to calculate the palyer's commission rate.
	public double CalculateCommission() {
		 double commission = (salary * commissionRate);
		 return commission;
		
	}

}
